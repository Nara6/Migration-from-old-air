public class PC_Lab306 {
    private int desk;
    boolean isDamaged;

    public PC_Lab306(int desk, boolean isDamaged) {
        this.desk = desk;
        this.isDamaged = isDamaged;
    }

    public int getDesk() {
        return this.desk;
    }

    public void setDesk(int desk) {
        this.desk = desk;
    }

    public boolean isIsDamaged() {
        return this.isDamaged;
    }

    public boolean getIsDamaged() {
        return this.isDamaged;
    }

    public void setIsDamaged(boolean isDamaged) {
        this.isDamaged = isDamaged;
    }

}
