public class Display_Paragraph {
    public static void main(String[] args) {
        System.out.print("\\n\t\t\t\t\t\t\t\t\t\t\t\t  Line Break.");
        System.out.print("\n\\t\t\t\t\t\t\t\t\t\t\t\t\t  Tabulation.");
        System.out.print("\n\\'\t\t\t\t\t\t\t\t\t\t\t\tSingle Quote.");
        System.out.print("\n\\\"\t\t\t\t\t\t\t\t\t\t\t\tDouble Quote.");
        System.out.print("\n\\\t\t\t\t\t\t\t\t\t\t\t\t\t\\   Sign.");
        System.out.print("\n\\\\\\\\\t\t\t\t\t\t\t\t\t\t\t\t\\\\  Sign.");
        System.out.print("\n//\t\t\t\t\t\t\t\t\t\t\t\tLine Comment.");
        System.out.print("\n/* ... */\t\t\t\t\t\t\t\t\t   Block Comment.");
        System.out.print("\n\"\"\"\n \t\t\t\t\t\t\t\t\t\t\t\t  Text Block.\n\"\"\"");
    }
}
