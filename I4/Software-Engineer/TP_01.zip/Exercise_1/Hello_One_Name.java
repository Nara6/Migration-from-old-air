public class Hello_One_Name {
    public static void main(String[] args) {
        System.out.println("Hello Nara!");
    }
}
