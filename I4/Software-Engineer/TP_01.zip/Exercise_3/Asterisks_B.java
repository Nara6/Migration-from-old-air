public class Asterisks_B {
    public static void main(String[] args) {
        System.out.println("B.");
        System.out.print("            *\n");
        System.out.print("          * * *\n");
        System.out.print("        * * * * *\n");
        System.out.print("      * * * * * * *\n");
        System.out.print("    * * * * * * * * *\n");
    }
}
