public class Asterisks_D {
    public static void main(String[] args) {
        System.out.println("D.");
        System.out.print("                   *\n");
        System.out.print("               * * *\n");
        System.out.print("           * * * * *\n");
        System.out.print("       * * * * * * *\n");
        System.out.print("   * * * * * * * * *\n");
    }
}
