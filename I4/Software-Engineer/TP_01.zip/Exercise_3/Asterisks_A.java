public class Asterisks_A {
    public static void main(String[] args) {
        System.out.println("A.");
        System.out.print("   ***************************\n");
        System.out.print("   *                         *\n");
        System.out.print("   *                         *\n");
        System.out.print("   *                         *\n");
        System.out.print("   *                         *\n");
        System.out.print("   ***************************\n");
    }
}
