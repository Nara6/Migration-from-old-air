public class Asterisks_H {
    public static void main(String[] args) {
        System.out.println("H.");
        System.out.print("             *\n");
        System.out.print("          *     * \n");
        System.out.print("       *           *\n");
        System.out.print("          *     * \n");
        System.out.print("             *\n");
    }
}
