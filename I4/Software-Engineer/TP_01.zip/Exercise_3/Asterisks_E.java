public class Asterisks_E {
    public static void main(String[] args) {
        System.out.println("E.");
        System.out.print("                    *\n");
        System.out.print("                * * *\n");
        System.out.print("            * * * * *\n");
        System.out.print("                * * *\n");
        System.out.print("                    *\n");
    }
}
