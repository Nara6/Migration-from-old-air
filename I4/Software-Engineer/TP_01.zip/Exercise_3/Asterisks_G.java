public class Asterisks_G {
    public static void main(String[] args) {
        System.out.println("G.");
        System.out.print("       * * * * *\n");
        System.out.print("         * * *\n");
        System.out.print("           *\n");
        System.out.print("         * * *\n");
        System.out.print("       * * * * *\n");
    }
}
