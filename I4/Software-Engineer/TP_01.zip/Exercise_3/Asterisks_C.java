public class Asterisks_C {
    public static void main(String[] args) {
        System.out.println("C.");
        System.out.print("    *\n");
        System.out.print("    * * *\n");
        System.out.print("    * * * * *\n");
        System.out.print("    * * * * * * *\n");
        System.out.print("    * * * * * * * * *\n");
    }
}
