public class Asterisks_F {
    public static void main(String[] args) {
        System.out.println("F.");
        System.out.print("           *\n");
        System.out.print("         * * *\n");
        System.out.print("       * * * * *\n");
        System.out.print("         * * *\n");
        System.out.print("           *\n");
    }
}
