package itc.gic.edu.TP16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Tp16ApplicationTests {

	@Test
	void contextLoads() {
	}

}
