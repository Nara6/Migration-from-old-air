package itc.gic.edu.TP16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp16Application {

	public static void main(String[] args) {
		SpringApplication.run(Tp16Application.class, args);
	}

}
