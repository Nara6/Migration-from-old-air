package ORMs;

import Model.City;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import java.sql.Statement;


public class CityORM extends ORM<City>{
    public CityORM(){
        tableName="cities";
    }

    @Override
    public ArrayList<City> listAll(){
        ArrayList<City> ar = new ArrayList<>();
        try(var stmt = connection.createStatement()){
            ResultSet rs = stmt.executeQuery("SELECT * FROM "+tableName);
            while(rs.next()){
                // ar.add(new City(rs.getInt("id"),rs.getString("city"),rs.getInt("countryid")));
                ar.add(new City(rs.getInt("id"),rs.getString("city"),rs.getInt("countryid")));
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return ar;
    }
    public City add(City t) {
        try(var stmt = connection.prepareStatement("INSERT INTO "+tableName
            +" VALUES(NULL,?,?)", Statement.RETURN_GENERATED_KEYS)){
            stmt.setString(1, t.getCity());
            stmt.setInt(2,t.getCountryid());
            stmt.execute();
            var rs = stmt.getGeneratedKeys();
            if(rs.next()) t.setId(rs.getInt(1));
        }catch(SQLException e){
            e.printStackTrace();
        }
        return t;
    }
    @Override
    public boolean delete(int id){
        try(var stmt = connection.prepareStatement("DELETE FROM "+tableName+" WHERE id="+id)){
            stmt.execute();
            return true;
        }catch(SQLException e){
            e.printStackTrace();
            return false;
        }
    }
    @Override
    public void update(City t){
        try(var stmt = connection.prepareStatement("UPDATE "+tableName+" SET city=?, countryid=? WHERE id=?")){
            stmt.setString(1,t.getCity());
            stmt.setInt(2,t.getCountryid());
            stmt.setInt(3,t.getId());
            stmt.executeUpdate();
        }catch(SQLException e){
            e.printStackTrace();
        }
    }
    @Override
    public ArrayList<City> rawQueryList(String query){
        ArrayList<City> ar = new ArrayList<>();
        try(var stmt = connection.createStatement()){
            ResultSet rs = stmt.executeQuery(query);
            while(rs.next()){
                ar.add(new City(rs.getInt("id"),rs.getString("city"),rs.getInt("countryid")));
            }
        }catch(SQLException e){
            e.printStackTrace();
        }
        return ar;
    }
    public static void main(String[] args) {
        var orm = new CityORM();
        // orm.listAll();
        // var country = new Country(0,"Laos");
        //orm.add(country);
        // System.out.println("New added country id: "+country.getId());
        // orm.delete(3);
        // int hold=0;
        // System.out.println("Please Input a ID: ");
        // Scanner sc = new Scanner(System.in);
        // int id = sc.nextInt();
        // for(var c:orm.listAll()){
        //     if(id==c.getId()){
        //         hold++;
        //     }
        // }
        // if(hold==0){
        //     System.out.println("ID not found!!");
        // }else{
        //     System.out.println("Found!!");
        //     System.out.print("New Country: ");
        //     String newCountry = sc.next();
        //     System.out.print("Country ID: ");
        //     int newCountryID = sc.nextInt();
        //     var City = new City(id,newCountry,newCountryID);
        //     orm.update(City);
        // }
        // var city = new City(0,"Bangkok",3);
        //orm.add(city);
        for(var c: orm.rawQueryList("SELECT * FROM cities")){
            System.out.println("Id: "+c.getId()
            +", Name: "+c.getCity()+",CountryID: "+c.getCountryid());
        }
        // for (var c : orm.listAll()) {
            // System.out.println("Id: "+c.getId()
            //     +", Name: "+c.getCity()+",CountryID: "+c.getCountryid());
        // }
    }
}
