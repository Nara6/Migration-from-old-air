
public class CategoryTest{

    public static void main(String[] args){
        Category c = new Category();
        c.addCategory();
        c.listBookCategory();
        c.findBook();
        c.addRemoveBook();
        c.countBook();
    }
}