
public class Point3DTest {
    public static void main(String[] args){
        Point3D point3D = Point3D.dataInput();
        System.out.println(point3D);
    }
}
