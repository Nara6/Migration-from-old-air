public class Ex2 {
    public static void main(String[] args) {
        for (int i = 0; i <= 500; i++) {
            if (i % 2 != 0 && i != 0) {
                System.out.print(i + " ");
            }
        }
    }
}
