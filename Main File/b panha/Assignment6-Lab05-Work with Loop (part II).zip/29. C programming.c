#include<stdio.h>
main(){
    int a=0;
    while(a<=99){
        a=a+1;
        if(a%2==1){
            printf("%d ",a);
        }
    }

}
