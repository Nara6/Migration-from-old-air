#include<stdio.h>
main(){

    int n,i;
    printf("Enter the n number: ");
    scanf("%d",&n);
    i=n;
    while(i>0){
        printf("%d ",i);
        i=i-1;
    }

}
