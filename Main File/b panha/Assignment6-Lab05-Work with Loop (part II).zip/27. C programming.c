#include<stdio.h>
main(){
    int a=96,b=121;
    char chr;
    while(a<=b){
        a=a+1;
        chr=a;
        printf("%c ",chr);
    }

}
