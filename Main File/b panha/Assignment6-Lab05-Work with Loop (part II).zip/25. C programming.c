#include<stdio.h>
main(){
    int n,i;
    printf("Enter the n number: ");
    scanf("%d",&n);
    i=1;
    while(i<=n){
        printf("%d ",i);
        i=i+1;
    }

}
