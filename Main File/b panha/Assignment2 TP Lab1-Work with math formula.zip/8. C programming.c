#include<stdio.h>
main(){

//Problem5

    float x,y,f1,f2,f3,f4,f5 ;
    printf("Enter the x value:");
    scanf("%f",&x);
    printf("Enter the y value:");
    scanf("%f",&y);

    f1=(2*x)-(3*y);
    f2=3*x/2;
    f3=(pow(x,3))-(5*x/2)+sqrt(pow(y,3));
    f4=(x+sqrt(y))/(2*x);
    f5=sin(x)+tan(y);
    printf("\n");
    printf("The result of f1=%.3f\n",f1);
    printf("The result of f2=%.3f\n",f2);
    printf("The result of f3=%.3f\n",f3);
    printf("The result of f4=%.3f\n",f4);
    printf("The result of f5=%.3f\n",f5);



}
