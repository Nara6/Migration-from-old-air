#include<stdio.h>
main(){

//Problem2

    int num,square,cube;
    printf("Enter the number: ");
    scanf("%d",&num);
    square=pow(num,2);
    cube=pow(num,3);
    printf("Square of %d is %d AND cube of %d is %d.",num,square,num,cube);



}
