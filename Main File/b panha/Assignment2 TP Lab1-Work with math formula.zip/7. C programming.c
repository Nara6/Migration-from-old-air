#include<stdio.h>
main(){

//Problem4

    int hour,minute,second,total,lesssecond;
    printf("Input time in second (s) : ");
    scanf("%d",&total);

    hour=total/3600;
    lesssecond=total%3600;
    minute=lesssecond/60;
    second=lesssecond%60;

    printf("It is: %dh %dmn %ds ",hour,minute,second);

}
