#include<stdio.h>

main(){

//Problem1

    printf("HELLO WORLD !\n");
    printf("-------------\n");
    printf("\n");
    printf("N  N\n");
    printf("NN N\n");
    printf("N NN\n");
    printf("N  N\n");
    printf("\n");
    printf("   *   \n");
    printf("  * *  \n");
    printf(" *   * \n");
    printf("*******\n");
    printf("\n");
    printf("***************************************\n");
    printf("* Institut de Technologie du Cambodge *\n");
    printf("***************************************\n");
    printf("\n");
    printf(" ======================================\n");
    printf("/ G�nie Informatique et Communication /\n");
    printf("====================================== \n");


}
