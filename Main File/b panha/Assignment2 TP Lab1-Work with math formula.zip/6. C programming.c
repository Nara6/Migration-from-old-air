#include<stdio.h>
main(){

//Problem3

    int hour,minute,second,total;
    printf("Enter hour: "); scanf("%d",&hour);
    printf("Enter minute: "); scanf("%d",&minute);
    printf("Enter second: "); scanf("%d",&second);
    total=(hour*3600)+(minute*60)+second;
    printf("The above time is equal to %d seconds.",total);


}
