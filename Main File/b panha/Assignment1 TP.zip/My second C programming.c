#include<stdio.h>
main(){
    int a,b,n;
    a=2;
    b=3;
    n=a+b;
    printf("%d+%d=%d\n",a,b,n);
    printf("--");
}
