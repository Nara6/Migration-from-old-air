#include<stdio.h>
main(){
    printf("--\n");
    printf("Hello everyone!\n");
    printf("My name is Pagna.\n");
    printf("I am a year 3.\t I am from department GIC.\n");
    printf("Welcome to C programming!\n\n");
    printf("Hello world!\n");
    printf("--");
}
