#include<stdio.h>

main(){
    char name[20];
    int yearofbirth, age, currentyears=2020;

    printf("Enter your name: ");
    scanf("%s", &name);

    printf("Enter your year of birth: ");
    scanf("%d", &yearofbirth);

    age=currentyears-yearofbirth;

    printf("\nHi %s! you are %d year old\n",name,age);
}
