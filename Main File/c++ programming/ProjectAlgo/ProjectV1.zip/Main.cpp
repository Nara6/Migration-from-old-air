#include<iostream>
#include"function.h"
using namespace std;

int main(){
    while(1){
    //summation();
    //subtraction();
    //multiplication();
    //division();
    //sum1ToN();
    //sumOdd1ToN();
    //sumSquare();
    //sumPrimeNum();
    //convertBase2to10();
    //convertBase10to2();
    //convertBase8to10();
    //convertBase10to8();
    //convertBase10to16();
    ifPrime();
    //ifPerfect();
    //ifPalindrome();
    }
    
}