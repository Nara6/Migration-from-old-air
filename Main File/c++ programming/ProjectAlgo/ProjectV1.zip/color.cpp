#include<iostream>
#include<stdlib.h>
using namespace std;

int main(){
    system("Color 04");
    cout<<"Meow";
}