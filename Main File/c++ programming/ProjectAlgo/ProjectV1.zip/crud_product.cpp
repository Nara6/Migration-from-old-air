#include<iostream>
#include<fstream>
#include<string.h>
using namespace std;

struct product{
    int ID;
    string name;
    int qty;
    string category;
    float standard_price;
    float amount;
};
product Product[100];
int i=0;
void createNewProduct(){
    cout<<"\t\t*Create New Product.\n";
    cout<<"\tID: ";cin>>Product[i].ID;
    cout<<"\tName: "; getline(cin>>ws,Product[i].name);
    cout<<"\tCategory: "; getline(cin>>ws,Product[i].category);
    cout<<"\tQuantity: "; cin>>Product[i].qty;
    cout<<"\tStandard Price: "; cin>>Product[i].standard_price;
    Product[i].amount = Product[i].qty*Product[i].standard_price;
    i++;
}
void insertToFile(){
    fstream F1;
    F1.open("product.txt", ios::app);
    //F1<<"ID\tName\tCategory\tQty\tPrice\tAmount"<<endl;
    for(int k=0; k<i; k++){
        F1<<Product[k].ID<<"\t"<<Product[k].name<<"\t"<<Product[k].category<<"\t"<<Product[k].qty<<"\t"<<Product[k].standard_price<<"\t"<<Product[k].amount<<endl;
    }
    i--;
}
void readFromFile(){
    fstream F2;
    //int l=0;
    //string des;
    F2.open("product.txt", ios::in);
    while(!F2.eof()){
        F2>>Product[i].ID;
        F2>>Product[i].name;
        F2>>Product[i].category;
        F2>>Product[i].qty;
        F2>>Product[i].standard_price;
        F2>>Product[i].amount;
        i++;
        
    }
    //cout<<Product[l].ID;
    for(int j=0; j<i; j++){
        //cout<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<Product[j].amount<<endl;
        cout<<Product[j].ID<<"\t";
        cout<<Product[j].name<<"\t";
        cout<<Product[j].category<<"\t";
        cout<<Product[j].qty<<"\t";
        cout<<Product[j].standard_price<<"\t";
        cout<<Product[j].amount<<endl;
        
    }
    F2.close();
}
void readByID(){
    int ID,c=0;
    cout<<"Product ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(Product[j].ID==ID){
            cout<<Product[j].ID<<"\t";
            cout<<Product[j].name<<"\t";
            cout<<Product[j].category<<"\t";
            cout<<Product[j].qty<<"\t";
            cout<<Product[j].standard_price<<"\t";
            cout<<Product[j].amount<<endl;
            c++;
        }
    }
    if(c==0){
        cout<<"Product Not Found!"<<endl;
    }
}
void deleteByID(){
    int ID;
    fstream old,New;
    old.open("product.txt", ios::in);
    New.open("new_product.txt", ios::out);
    cout<<"Enter an ID Product: ";cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Product[j].ID){
            cout<<"\tProduct Successfully Deleted!"<<endl;
        }else{
            if(ID!=Product[j].ID){
                New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl;
            }else{
                New<<Product[j].ID-1<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl;
            }
        }
    }
    old.close();
    New.close();
    remove("product.txt");
    rename("new_product.txt", "product.txt");
}
void updateID(int ID){
    int newID;
    fstream old,New;
    old.open("product.txt", ios::in);
    New.open("new_product.txt", ios::out);
    //cout<<"Enter an ID Product: ";cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Product[j].ID){
            cout<<"New ID: "; cin>>newID;
            Product[j].ID = newID;
            New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl;
            cout<<"\tProduct Successfully Updated!"<<endl;
        }else{
            New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl; 
        }
    }
    old.close();
    New.close();
    remove("product.txt");
    rename("new_product.txt", "product.txt");
}
void updateName(int ID){
    //int ID;
    string newName;
    fstream old,New;
    old.open("product.txt", ios::in);
    New.open("new_product.txt", ios::out);
    //cout<<"Enter an ID Product: ";cin>>ID;
    for(int j=0; j<i; j++){
        if(Product[j].ID == ID){
            cout<<"New Name: "; cin>>newName;
            Product[j].name = newName;
            New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl;
            cout<<"\tProduct Successfully Updated!"<<endl;
        }else{
            New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl; 
        }
    }
    old.close();
    New.close();
    remove("product.txt");
    rename("new_product.txt", "product.txt");
}
void updateCategory(int ID){
    //int ID;
    string newCategory;
    fstream old,New;
    old.open("product.txt", ios::in);
    New.open("new_product.txt", ios::out);
    //cout<<"Enter an ID Product: ";cin>>ID;
    for(int j=0; j<i; j++){
        if(Product[j].ID == ID){
            cout<<"New Category: "; cin>>newCategory;
            Product[j].category = newCategory;
            New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl;
            cout<<"\tProduct Successfully Updated!"<<endl;
        }else{
            New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl; 
        }
    }
    old.close();
    New.close();
    remove("product.txt");
    rename("new_product.txt", "product.txt");
}
void updateQty(int ID){
    //int ID;
    int newQty;
    fstream old,New;
    old.open("product.txt", ios::in);
    New.open("new_product.txt", ios::out);
    //cout<<"Enter an ID Product: ";cin>>ID;
    for(int j=0; j<i; j++){
        if(Product[j].ID == ID){
            cout<<"New Quantity: "; cin>>newQty;
            Product[j].qty = newQty;
            Product[j].amount = Product[j].standard_price * Product[j].qty;
            New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl;
            cout<<"\tProduct Successfully Updated!"<<endl;
        }else{
            New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl; 
        }
    }
    old.close();
    New.close();
    remove("product.txt");
    rename("new_product.txt", "product.txt");
}
void updateStandardPrice(int ID){
    //int ID;
    double newSP;
    fstream old,New;
    old.open("product.txt", ios::in);
    New.open("new_product.txt", ios::out);
    //cout<<"Enter an ID Product: ";cin>>ID;
    for(int j=0; j<i; j++){
        if(Product[j].ID == ID){
            cout<<"New Stadard Price: "; cin>>newSP;
            Product[j].standard_price = newSP;
            New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl;
            cout<<"\tProduct Successfully Updated!"<<endl;
        }else{
            New<<Product[j].ID<<"\t"<<Product[j].name<<"\t"<<Product[j].category<<"\t"<<Product[j].qty<<"\t"<<Product[j].standard_price<<"\t"<<Product[j].amount<<endl; 
        }
    }
    old.close();
    New.close();
    remove("product.txt");
    rename("new_product.txt", "product.txt");
}
void searchByID(){
    int ID,c=0;
    cout<<"Product ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(Product[j].ID==ID){
            cout<<Product[j].ID<<"\t";
            cout<<Product[j].name<<"\t";
            cout<<Product[j].category<<"\t";
            cout<<Product[j].qty<<"\t";
            cout<<Product[j].standard_price<<"\t";
            cout<<Product[j].amount<<endl;
            c++;
        }
    }
    if(c==0){
        cout<<"Product Not Found!"<<endl;
    }
}
void searchByName(){
    string name;
    int c=0;
    cout<<"Product Name: "; cin>>name;
    //name = toupper(name);
    for(int j=0; j<i; j++){
        //toupper(Product[j].name);
        if(Product[j].name==name){
            cout<<Product[j].ID<<"\t";
            cout<<Product[j].name<<"\t";
            cout<<Product[j].category<<"\t";
            cout<<Product[j].qty<<"\t";
            cout<<Product[j].standard_price<<"\t";
            cout<<Product[j].amount<<endl;
            c++;
        }
    }
    if(c==0){
        cout<<"Product Not Found!"<<endl;
    }
}
void searchByCategory(){
    string category;
    int c=0;
    cout<<"Product Category: "; cin>>category;
    for(int j=0; j<i; j++){
        if(Product[j].category==category){
            cout<<Product[j].ID<<"\t";
            cout<<Product[j].name<<"\t";
            cout<<Product[j].category<<"\t";
            cout<<Product[j].qty<<"\t";
            cout<<Product[j].standard_price<<"\t";
            cout<<Product[j].amount<<endl;
            c++;
        }
    }
    if(c==0){
        cout<<"Product Not Found!"<<endl;
    }
}
void searchByQty(){
    int qty;
    int c=0;
    cout<<"Product Quantity: "; cin>>qty;
    for(int j=0; j<i; j++){
        if(Product[j].qty==qty){
            cout<<Product[j].ID<<"\t";
            cout<<Product[j].name<<"\t";
            cout<<Product[j].category<<"\t";
            cout<<Product[j].qty<<"\t";
            cout<<Product[j].standard_price<<"\t";
            cout<<Product[j].amount<<endl;
            c++;
        }
    }
    if(c==0){
        cout<<"Product Not Found!"<<endl;
    }
}
void searchByStandardPrice(){
    float SP;
    int c=0;
    cout<<"Product Standard Price: "; cin>>SP;
    for(int j=0; j<i; j++){
        if(Product[j].standard_price==SP){
            cout<<Product[j].ID<<"\t";
            cout<<Product[j].name<<"\t";
            cout<<Product[j].category<<"\t";
            cout<<Product[j].qty<<"\t";
            cout<<Product[j].standard_price<<"\t";
            cout<<Product[j].amount<<endl;
            c++;
        }
    }
    if(c==0){
        cout<<"Product Not Found!"<<endl;
    }
}
void searchByAmount(){
    float amount;
    int c=0;
    cout<<"Product Amount: "; cin>>amount;
    for(int j=0; j<i; j++){
        if(Product[j].amount==amount){
            cout<<Product[j].ID<<"\t";
            cout<<Product[j].name<<"\t";
            cout<<Product[j].category<<"\t";
            cout<<Product[j].qty<<"\t";
            cout<<Product[j].standard_price<<"\t";
            cout<<Product[j].amount<<endl;
            c++;
        }
    }
    if(c==0){
        cout<<"Product Not Found!"<<endl;
    }
}

int main(){
    // createNewProduct();
    // createNewProduct();
    // insertToFile();
    readFromFile();
    //readByID();
    //deleteByID();
    //updateID();
    //updateName();
    //updateQty();
    //updateStandardPrice();
    //displayProduct();
    //searchByName();
    //searchByCategory();
    //searchByQty();
    //searchByStandardPrice();
    //searchByAmount();
}