#include<iostream>
#include<fstream>
#include<iomanip>
using namespace std;
struct book{
    int ID;
    float price;
    string ISBN;
    string title;
    string author;
    string type;
    string publisher;
    string publish_date;
};
book Book[100];
int i=0;
void CreateNew(){
    //book Book;
    cout<<"\t\t*Create New Book!\n";
    cout<<"\tID: "; cin>>Book[i].ID;
    cout<<"\tISBN: "; cin>>Book[i].ISBN;
    cout<<"\tTitle: "; getline(cin>>ws,Book[i].title);
    cout<<"\tType: "; getline(cin>>ws,Book[i].type);
    cout<<"\tPrice: "; cin>>Book[i].price;
    cout<<"\tAuthor: "; getline(cin>>ws,Book[i].author);
    cout<<"\tPublisher: "; getline(cin>>ws,Book[i].publisher);
    cout<<"\tPublish Date: "; getline(cin>>ws,Book[i].publish_date);
    i++;
}
void insertToFile(){
    fstream insert;
    insert.open("books.txt", ios::app);
    for(int j=0; j<i; j++){
        insert<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
    }
    insert.close();
    i--;
}
void readFromFile(){
    fstream read;
    read.open("book.txt", ios::in);
    //read.ignore();
    while(!read.eof()){
        //cout<<"meow"<<"\t"<<endl;
        read>>Book[i].ID;
        read>>Book[i].ISBN;
        read>>Book[i].title;
        read>>Book[i].type;
        read>>Book[i].price;
        read>>Book[i].author;
        read>>Book[i].publisher;
        read>>Book[i].publish_date;
        i++;
    }
    //cout<<i;
    cout<<"===================================================================================================================================\n";
    cout<<"ID: "<<setw(13)<<"ISBN: "<<setw(19)<<"Title: "<<setw(20)<<"Type: "<<setw(13)<<"Price: "<<setw(20)<<"Author:"<<setw(20)<<"Publisher: "<<setw(23)<<"Publish date: ";
    cout<<"\n===================================================================================================================================\n";
    for(int j=0; j<i; j++){
        cout<<"|";
        cout<<Book[j].ID;
        cout<<setw(15)<<Book[j].ISBN;
        cout<<setw(20)<<Book[j].title;
        cout<<setw(20)<<Book[j].type;
        cout<<setw(10)<<Book[j].price;
        cout<<setw(25)<<Book[j].author;
        cout<<setw(20)<<Book[j].publisher;
        cout<<setw(19)<<Book[j].publish_date;
        cout<<"|";
        cout<<endl;
        
    }
    read.close();
}
void updateID(){
    int ID,newID;
    fstream old,New;
    old.open("book.txt", ios::in);
    New.open("new_book.txt", ios::out);
    cout<<"Enter an ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Book[j].ID){
            cout<<"Enter new ID: "; cin>>newID;
            Book[j].ID = newID;
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
            cout<<"\tBook Successfully Updated!"<<endl;
        }else{
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
        }
    }
    old.close();
    New.close();
    remove("book.txt");
    rename("new_book.txt", "book.txt");
}
void updateISBN(){
    int ID;
    string ISBN;
    fstream old,New;
    old.open("book.txt", ios::in);
    New.open("new_book.txt", ios::out);
    cout<<"Enter an ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Book[j].ID){
            cout<<"Enter new ISBN: "; cin>>ISBN;
            Book[j].ISBN = ISBN;
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
            cout<<"\tBook Successfully Updated!"<<endl;
        }else{
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
        }
    }
    old.close();
    New.close();
    remove("book.txt");
    rename("new_book.txt", "book.txt");
}
void updateTitle(){
    int ID;
    string title;
    fstream old,New;
    old.open("book.txt", ios::in);
    New.open("new_book.txt", ios::out);
    cout<<"Enter an ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Book[j].ID){
            cout<<"Enter new Title: "; cin>>title;
            Book[j].title = title;
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
            cout<<"\tBook Successfully Updated!"<<endl;
        }else{
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
        }
    }
    old.close();
    New.close();
    remove("book.txt");
    rename("new_book.txt", "book.txt");
}
void updateType(){
    int ID;
    string type;
    fstream old,New;
    old.open("book.txt", ios::in);
    New.open("new_book.txt", ios::out);
    cout<<"Enter an ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Book[j].ID){
            cout<<"Enter new Type: "; cin>>type;
            Book[j].type = type;
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
            cout<<"\tBook Successfully Updated!"<<endl;
        }else{
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
        }
    }
    old.close();
    New.close();
    remove("book.txt");
    rename("new_book.txt", "book.txt");
}
void updatePrice(){
    int ID;
    float price;
    fstream old,New;
    old.open("book.txt", ios::in);
    New.open("new_book.txt", ios::out);
    cout<<"Enter an ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Book[j].ID){
            cout<<"Enter new Price: "; cin>>price;
            Book[j].price = price;
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
            cout<<"\tBook Successfully Updated!"<<endl;
        }else{
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
        }
    }
    old.close();
    New.close();
    remove("book.txt");
    rename("new_book.txt", "book.txt");
}
void updateAuthor(){
    int ID;
    string author;
    fstream old,New;
    old.open("book.txt", ios::in);
    New.open("new_book.txt", ios::out);
    cout<<"Enter an ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Book[j].ID){
            cout<<"Enter new Author: "; cin>>author;
            Book[j].author = author;
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
            cout<<"\tBook Successfully Updated!"<<endl;
        }else{
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
        }
    }
    old.close();
    New.close();
    remove("book.txt");
    rename("new_book.txt", "book.txt");
}
void updatePublisher(){
    int ID;
    string publisher;
    fstream old,New;
    old.open("book.txt", ios::in);
    New.open("new_book.txt", ios::out);
    cout<<"Enter an ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Book[j].ID){
            cout<<"Enter new Publisher: "; cin>>publisher;
            Book[j].publisher = publisher;
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
            cout<<"\tBook Successfully Updated!"<<endl;
        }else{
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
        }
    }
    old.close();
    New.close();
    remove("book.txt");
    rename("new_book.txt", "book.txt");
}
void updatePublishDate(){
    int ID;
    string publish_date;
    fstream old,New;
    old.open("book.txt", ios::in);
    New.open("new_book.txt", ios::out);
    cout<<"Enter an ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Book[j].ID){
            cout<<"Enter new Publish Date: "; cin>>publish_date;
            Book[j].publish_date = publish_date;
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
            cout<<"\tBook Successfully Updated!"<<endl;
        }else{
            New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
        }
    }
    old.close();
    New.close();
    remove("book.txt");
    rename("new_book.txt", "book.txt");
}
void deleteByID(){
    int ID;
    fstream old,New;
    old.open("book.txt", ios::in);
    New.open("new_book.txt", ios::out);
    cout<<"Enter an ID: "; cin>>ID;
    for(int j=0; j<i; j++){
        if(ID == Book[j].ID){
            cout<<"\tProduct Successfully deleted!"<<endl;
        }else{
            if(ID != Book[j].ID){
                New<<Book[j].ID<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
            }else{
                New<<Book[j].ID - 1<<"\t"<<Book[j].ISBN<<"\t"<<Book[j].title<<"\t"<<Book[j].type<<"\t"<<Book[j].price<<"\t"<<Book[j].author<<"\t"<<Book[j].publisher<<"\t"<<Book[j].publish_date<<endl;
            }
        }
    }
    old.close();
    New.close();
    remove("book.txt");
    rename("new_book.txt", "book.txt");
}

int main(){
    //CreateNew();
    //displayBook();
    //insertToFile();
    //CreateNew();
    //insertToFile();
    //cout<<i;
    readFromFile();
    //updateID();
    //updateISBN();
    //updateTitle();
    //updateType();
    //updatePrice();
    //updateAuthor();
    //updatePublisher();
    //updatePublishDate();
    //deleteByID();
}