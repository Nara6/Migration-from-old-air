#include<stdio.h>

typedef struct{
    char name[25];
    char fater_name[25];
    char mother_name[25];
}Person;
void DisplayName( Person person[],int size){
    
}