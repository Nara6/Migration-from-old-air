#include<stdio.h>

main(){
    int i;
    for(i=0; i<=255; i++) 
    {
        printf("ASCII value of character %d = %c\n", i, i);
    }
}