#include<stdio.h>

main(){
    int a=96 , b=121;
    char t;
    while(a<=b){
        a = a + 1;
        t = a;
        printf("%c ", t);
    }
}